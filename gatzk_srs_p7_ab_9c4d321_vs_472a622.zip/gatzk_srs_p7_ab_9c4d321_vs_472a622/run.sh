#!/usr/bin/env bash
set -u

REPO="${1:-$HOME/project}"
BASE_SHA="472a622acf37fa79b2116d6c5f5f72c43bf50cf2"
NEW_SHA="9c4d3219bb1f5bd9b56df7575168532883485b62"
JOBS="${GATZK_VERIFY_JOBS:-2}"
SRS="$REPO/artifacts/srs/cora_formal_srs"
ID="cora_formal_srs"
HERE="$(cd "$(dirname "$0")" && pwd)"
WORK="/tmp/gatzk_srs_p7_ab_$$"
LOG="$HOME/gatzk_verify_logs/srs_p7_ab_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$WORK" "$LOG"
trap 'rm -rf "$WORK"' EXIT

cd "$REPO" || exit 2
HEAD="$(git rev-parse HEAD 2>/dev/null || true)"
if [ "$HEAD" != "$NEW_SHA" ]; then
  echo "FAIL exact_head expected=$NEW_SHA actual=$HEAD"
  exit 2
fi
if ! git diff --quiet || ! git diff --cached --quiet; then
  echo "FAIL tracked_worktree_not_clean"
  git status --short
  exit 2
fi
if [ ! -f "$SRS/pk_coef.bin" ] || [ ! -f "$SRS/srs_manifest.json" ]; then
  echo "FAIL missing_cora_srs"
  exit 2
fi
if [ ! -f "$REPO/third_party/mcl/CMakeLists.txt" ]; then
  echo "FAIL missing_mcl_submodule"
  exit 2
fi

read DOMAIN_SIZE POINT_COUNT SMALL LARGE <<EOF2
$(python3 - "$SRS" <<'PY'
import json, os, struct, sys
srs=sys.argv[1]
with open(os.path.join(srs,'srs_manifest.json')) as f:
    m=json.load(f)
with open(os.path.join(srs,'pk_coef.bin'),'rb') as f:
    magic=f.read(8)
    count=struct.unpack('<Q',f.read(8))[0]
    psz=struct.unpack('<Q',f.read(8))[0]
if magic != b'GATZKG1C':
    raise SystemExit('unexpected pk_coef encoding')
d=int(m['domain_sizes']['C'])
small=max(65536,d+1)
large=max(262144,small+1)
small=min(small,count)
large=min(large,count)
if small <= d or large <= d:
    raise SystemExit('SRS too small for benchmark')
print(d,count,small,large)
PY
)
EOF2

echo "BASE_SHA=$BASE_SHA"
echo "NEW_SHA=$NEW_SHA"
echo "DOMAIN=C:$DOMAIN_SIZE"
echo "COUNTS=$SMALL,$LARGE"
echo "LOG_DIR=$LOG"

prepare_source() {
  label="$1"
  sha="$2"
  src="$WORK/src-$label"
  mkdir -p "$src"
  git archive "$sha" | tar -x -C "$src" || return 1
  mkdir -p "$src/third_party"
  rm -rf "$src/third_party/mcl"
  ln -s "$REPO/third_party/mcl" "$src/third_party/mcl"
}

build_one() {
  label="$1"
  src="$WORK/src-$label"
  build="$WORK/build-$label"
  cmake -S "$HERE" -B "$build" \
    -DGATZK_SOURCE_DIR="$src" \
    -DCMAKE_BUILD_TYPE=Release \
    -DGATZK_ENABLE_CUDA_BACKEND=OFF \
    -DGATZK_ENABLE_NATIVE_ARCH=OFF \
    >"$LOG/${label}_configure.log" 2>&1 || return 1
  cmake --build "$build" --target srs_prefix_once -j"$JOBS" \
    >"$LOG/${label}_build.log" 2>&1 || return 1
}

prepare_source base "$BASE_SHA" || { echo "FAIL prepare_base"; exit 1; }
prepare_source new "$NEW_SHA" || { echo "FAIL prepare_new"; exit 1; }
echo "PASS source_snapshots"

build_one base || { echo "FAIL build_base"; tail -n 30 "$LOG/base_build.log"; exit 1; }
build_one new || { echo "FAIL build_new"; tail -n 30 "$LOG/new_build.log"; exit 1; }
echo "PASS builds"

# Deliberately benchmark a warm page-cache regime so disk cold-start variance
# does not obscure the loader scheduling change under test.
cat "$SRS/pk_coef.bin" >/dev/null

echo "PASS page_cache_prewarm"
RESULTS="$LOG/results.tsv"
printf 'count\tround\tversion\tpk_ms\ttotal_ms\n' > "$RESULTS"

run_one() {
  version="$1"
  count="$2"
  round="$3"
  exe="$WORK/build-$version/srs_prefix_once"
  out="$LOG/${version}_${count}_r${round}.log"
  GATZK_RUN_PROGRESS=1 "$exe" "$SRS" "$ID" C "$DOMAIN_SIZE" "$count" >"$out" 2>&1
  rc=$?
  if [ $rc -ne 0 ]; then
    echo "FAIL runtime_${version}_${count}_r${round}"
    tail -n 30 "$out"
    return 1
  fi
  pk_ms="$(sed -n 's/.*kzg:srs:pk_coef:done:ms=\([0-9.]*\).*/\1/p' "$out" | tail -n 1)"
  total_ms="$(sed -n 's/.*SRS_PREFIX_ONCE_PASS count=[0-9]* total_ms=\([0-9.]*\).*/\1/p' "$out" | tail -n 1)"
  if [ -z "$pk_ms" ] || [ -z "$total_ms" ]; then
    echo "FAIL parse_${version}_${count}_r${round}"
    tail -n 30 "$out"
    return 1
  fi
  printf '%s\t%s\t%s\t%s\t%s\n' "$count" "$round" "$version" "$pk_ms" "$total_ms" >> "$RESULTS"
  echo "PASS run count=$count round=$round version=$version pk_ms=$pk_ms total_ms=$total_ms"
}

for count in "$SMALL" "$LARGE"; do
  run_one base "$count" 1 || exit 1
  run_one new  "$count" 1 || exit 1
  run_one new  "$count" 2 || exit 1
  run_one base "$count" 2 || exit 1
  run_one base "$count" 3 || exit 1
  run_one new  "$count" 3 || exit 1
done

python3 - "$RESULTS" <<'PY'
import csv, statistics, sys
path=sys.argv[1]
rows=list(csv.DictReader(open(path), delimiter='\t'))
print('===== A/B SUMMARY =====')
all_good=True
for count in sorted({int(r['count']) for r in rows}):
    vals={}
    for version in ('base','new'):
        pk=[float(r['pk_ms']) for r in rows if int(r['count'])==count and r['version']==version]
        total=[float(r['total_ms']) for r in rows if int(r['count'])==count and r['version']==version]
        vals[version]=(statistics.median(pk), statistics.median(total))
    bpk,btotal=vals['base']; npk,ntotal=vals['new']
    pk_gain=(bpk-npk)/bpk*100.0
    total_gain=(btotal-ntotal)/btotal*100.0
    print(f'count={count} base_pk_ms={bpk:.3f} new_pk_ms={npk:.3f} pk_gain_pct={pk_gain:.2f} base_total_ms={btotal:.3f} new_total_ms={ntotal:.3f} total_gain_pct={total_gain:.2f}')
    if npk > bpk * 1.05:
        all_good=False
print('AB_NO_REGRESSION=' + ('PASS' if all_good else 'FAIL'))
PY
RC=$?
if [ $RC -ne 0 ]; then
  echo "FAIL summary"
  exit 1
fi

if git diff --quiet && git diff --cached --quiet; then
  echo "PASS tracked_repo_unchanged"
else
  echo "FAIL tracked_repo_unchanged"
  git status --short
  exit 1
fi

echo "===== FINAL ====="
echo "SRS_P7_AB_COMPLETE"
echo "RESULTS=$RESULTS"
echo "LOG_DIR=$LOG"
