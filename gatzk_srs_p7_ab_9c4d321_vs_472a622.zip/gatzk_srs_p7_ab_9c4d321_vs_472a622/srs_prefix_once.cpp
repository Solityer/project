#include <chrono>
#include <cstddef>
#include <exception>
#include <iostream>
#include <string>

#include <mcl/bn.hpp>
#include "gatzk/crypto/kzg.hpp"

using Clock = std::chrono::steady_clock;

int main(int argc, char **argv)
{
    try
    {
        if (argc != 6)
        {
            std::cerr << "usage: srs_prefix_once <srs-dir> <srs-id> <domain> <domain-size> <coefficient-count>\n";
            return 2;
        }

        mcl::bn::initPairing(mcl::BLS12_381);
        const std::string srs = argv[1];
        const std::string id = argv[2];
        const std::string domain = argv[3];
        const auto domain_size = static_cast<std::size_t>(std::stoull(argv[4]));
        const auto coefficient_count = static_cast<std::size_t>(std::stoull(argv[5]));
        if (coefficient_count <= domain_size)
        {
            throw std::runtime_error("coefficient count must exceed selected domain size");
        }

        const auto begin = Clock::now();
        const auto key = gatzk::crypto::KZG::load_keys_for_domains(
            srs,
            "trusted_srs",
            id,
            {{domain, domain_size}},
            coefficient_count);
        const auto end = Clock::now();

        if (!key.pk.powers_g1 || key.pk.powers_g1->size() != coefficient_count)
        {
            throw std::runtime_error("coefficient prefix size mismatch");
        }
        if (!key.pk.lagrange_srs_by_domain.contains(domain))
        {
            throw std::runtime_error("selected Lagrange domain missing");
        }

        const double total_ms =
            std::chrono::duration<double, std::milli>(end - begin).count();
        std::cout << "SRS_PREFIX_ONCE_PASS count=" << coefficient_count
                  << " total_ms=" << total_ms << "\n";
        return 0;
    }
    catch (const std::exception &error)
    {
        std::cerr << "SRS_PREFIX_ONCE_FAIL: " << error.what() << "\n";
        return 1;
    }
}
